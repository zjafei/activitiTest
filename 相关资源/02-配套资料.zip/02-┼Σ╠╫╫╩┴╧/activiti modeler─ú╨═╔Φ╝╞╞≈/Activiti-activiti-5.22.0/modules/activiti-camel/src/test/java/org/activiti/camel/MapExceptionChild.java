package org.activiti.camel;


public class MapExceptionChild extends MapExceptionParent {

  public MapExceptionChild(String string) {
    super(string);
  }

}
