package org.activiti.camel;


public class MapExceptionParent extends Exception {

  public MapExceptionParent(String string) {
    super(string);
  }

}
