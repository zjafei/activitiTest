package org.activiti.cdi.test.impl.beans;

import javax.enterprise.inject.Specializes;

import org.activiti.cdi.test.impl.util.ProgrammaticBeanLookupTest.TestBean;

@Specializes
public class SpecializedTestBean extends TestBean {

}
