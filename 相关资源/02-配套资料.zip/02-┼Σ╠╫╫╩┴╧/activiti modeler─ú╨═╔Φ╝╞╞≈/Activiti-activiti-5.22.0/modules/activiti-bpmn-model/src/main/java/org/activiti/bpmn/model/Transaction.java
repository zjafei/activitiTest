package org.activiti.bpmn.model;

public class Transaction extends SubProcess {

}
